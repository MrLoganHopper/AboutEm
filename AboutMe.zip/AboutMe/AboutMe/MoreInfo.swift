//
//  MoreInfo.swift
//  AboutMe
//
//  Created by Maia Rocha on 2/11/26.
//

import SwiftUI

struct MoreInfo: View {
    var body: some View {
        
        NavigationStack{
            Form{
                Section("Skills"){
                    Text("Tennis")
                    Text("Python")
                    Text("Driving")
                }
                Section("Languages"){
                    Text("Armenian")
                    Text("Russian")
                    Text("English")
                }
                
            }
            .navigationTitle("More Info")
        }
        
    }
}

#Preview {
    MoreInfo()
}
