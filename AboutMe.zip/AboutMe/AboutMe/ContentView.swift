//
//  ContentView.swift
//  AboutMe
//
//  Created by Maia Rocha on 2/11/26.
//

import SwiftUI

struct ContentView: View {
    let hobbies = ["cars", "listening to music","playing tennis"]
    var body: some View {
        
        
        ZStack{
            
            Color.orange
            
                .opacity(0.6)
                .ignoresSafeArea()
            
            
            
            VStack {
                Image("LUM_2914")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(30)
                    .padding()
                
                    .shadow(radius: 20)
                Text("Hey, I'm Vic")
                    .font(.system(size: 60))
                    .bold()
                    .fontDesign(.rounded)
                Text("I love \(hobbies.formatted())")
                
                HStack {
                    Image(systemName: "iphone.gen3")
                    Image(systemName: "macbook")
                    Image(systemName: "airpods")
                    Image(systemName: "applewatch")
                }
                .imageScale(.large)
                .padding()
                
                
                Text("Fun Fact")
                    .bold()
                
                Text("I speak 3 languages, Armenian, Russian, and English")
                
                
                
                
                Text("Favorite Apple Product")
                    .bold()
                Text("AirPods pro")
                
                
                
                
                
                
            }
            .padding()
            .multilineTextAlignment(.center)
            
        }
        
    }
}

#Preview {
    ContentView()
}
