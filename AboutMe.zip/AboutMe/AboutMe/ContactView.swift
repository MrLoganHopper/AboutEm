//
//  ContactView.swift
//  AboutMe
//
//  Created by Maia Rocha on 2/11/26.
//

import SwiftUI

struct ContactView: View {
    var body: some View {
        NavigationStack{
            VStack{
                Link(destination: URL(string: "instagram.com/avm.077")!){
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding()
                }
                
                .buttonBorderShape(.roundedRectangle(radius:30))
                .buttonStyle(.borderedProminent)
                    
                
            }
                .navigationTitle("Contact")
            
        }
    }
}

#Preview {
    ContactView()
}
