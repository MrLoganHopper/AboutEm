//
//  AboutMeTests.swift
//  AboutMeTests
//
//  Created by Maia Rocha on 2/11/26.
//

import Testing
@testable import AboutMe

struct AboutMeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
